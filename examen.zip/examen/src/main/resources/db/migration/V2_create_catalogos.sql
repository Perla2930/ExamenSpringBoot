
INSERT INTO materias(id, materia)
VALUES (1,'ESPAÑOL');

INSERT INTO materias(id, materia)
VALUES (2,'MATEMATICAS');

INSERT INTO materias(id, materia)
VALUES (3,'QUIMICA');

INSERT INTO materias(id, materia)
VALUES (4,'HISTORIA');