package com.exam.examen.controller.materias;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping(value="/api/V1/")
@RestController
public class materiasController {
	
	
	

}
