package com.exam.examen.entitys;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode

@Entity
@Table(name = "calificaciones", schema="public")

public class calificaciones {

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getAlumno() {
		return alumno;
	}

	public void setAlumno(int alumno) {
		this.alumno = alumno;
	}

	public int getMateria() {
		return materia;
	}

	public void setMateria(int materia) {
		this.materia = materia;
	}

	public int getCalificacion() {
		return calificacion;
	}

	public void setCalificacion(int calificacion) {
		this.calificacion = calificacion;
	}

	@Id
	@Column(name="id", unique = true)
	private int id;
	
	/*
	@OneToOne
	@JoinColumn(name="alumno", referencedColumnName = "id")
	*/
	@Column(name="alumno")
	private int alumno;
	
	/*
	@OneToOne
	@JoinColumn(name="materia", referencedColumnName = "id")
	*/
	
	@Column(name="materia")
	private int materia;
	
	@Column(name="calificacion")
	private int calificacion;
}
