package com.exam.examen.service.materias;

import java.util.List;

import com.exam.examen.entitys.materias;

public interface materiasService {
	
	public List<materias> getAllMaterias();
	
}
